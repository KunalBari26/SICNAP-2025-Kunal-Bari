Journal of the Audio Engineering Society
------------------------------------------

The following files are available in aes2e.zip archive:

aes2e.cls	           - This is the LaTeX2e class file for aes2e template
aes2e-guide.pdf    - This is PDF of Author Guide for aes2e template
aes2e-sample.pdf  - This is PDF file of sample LaTeX document for aes2e template
aes2e-sample.tex   - LaTeX document of sample
aes2e-mouse.eps   - Graphics file used in sample
aes2e.bib	  - bibTex library used in the sample
aes2e.bst         - bibTex style file used in the sample
cuted.sty                - This is the LaTeX2e style file for aes2e template


Happy TeXing!!!

Aptara